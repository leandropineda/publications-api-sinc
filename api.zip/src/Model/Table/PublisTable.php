<?php
namespace App\Model\Table;

use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Publis Model
 *
 * @method \App\Model\Entity\Publi get($primaryKey, $options = [])
 * @method \App\Model\Entity\Publi newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Publi[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Publi|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Publi patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Publi[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Publi findOrCreate($search, callable $callback = null)
 */
class PublisTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->table('publis');
        $this->displayField('title');
        $this->primaryKey('id');

        $this->belongsToMany('Authors', [
            'joinTable' => 'publiauthors',
            'foreignKey' => 'idPubli',
            'targetForeignKey' => 'idAuthor',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->requirePresence('bibTex', 'create')
            ->notEmpty('bibTex')
            ->add('bibTex', 'unique', ['rule' => 'validateUnique', 'provider' => 'table']);

        $validator
            ->requirePresence('entry', 'create')
            ->notEmpty('entry');

        $validator
            ->allowEmpty('address');

        $validator
            ->allowEmpty('booktitle');

        $validator
            ->allowEmpty('chapter');

        $validator
            ->allowEmpty('edition');

        $validator
            ->allowEmpty('editor');

        $validator
            ->allowEmpty('howpublished');

        $validator
            ->allowEmpty('institution');

        $validator
            ->allowEmpty('journal');

        $validator
            ->allowEmpty('keywords');

        $validator
            ->allowEmpty('month');

        $validator
            ->allowEmpty('note');

        $validator
            ->allowEmpty('number');

        $validator
            ->allowEmpty('optkey');

        $validator
            ->allowEmpty('organization');

        $validator
            ->allowEmpty('pages');

        $validator
            ->allowEmpty('publisher');

        $validator
            ->allowEmpty('school');

        $validator
            ->allowEmpty('series');

        $validator
            ->requirePresence('title', 'create')
            ->notEmpty('title');

        $validator
            ->allowEmpty('type');

        $validator
            ->allowEmpty('volume');

        $validator
            ->requirePresence('year', 'create')
            ->notEmpty('year');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->isUnique(['bibTex']));

        return $rules;
    }
}

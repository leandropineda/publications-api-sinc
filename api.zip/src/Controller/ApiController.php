<?php
/**
 * Created by javier
 * Date: 10/11/16
 * Time: 13:09
 */

namespace App\Controller;

use App\Model\Table\AuthorsTable;
use App\Model\Table\PublisTable;
use Cake\ORM\Query;

/**
 * Class ApiController
 * @package App\Controller
 *
 * @property AuthorsTable Authors
 * @property PublisTable Publis
 */
class ApiController extends AppController
{
    /**
     * 
     */
    public function initialize()
    {
        parent::initialize();

        $this->loadComponent('RequestHandler');
        $this->loadModel('Authors');
        $this->loadModel('Publis');
    }

    /**
     * 
     */
    public function publications()
    {
        $publications = $this->Publis->find()
            ->contain(['Authors'])
            ->order(['Publis.year' => 'desc', 'Publis.id' => 'desc']);

        if ($this->request->query('author_id')) {
            $authorId = $this->request->query('author_id');

            $publications->matching('Authors', function (Query $q) use ($authorId) {
                return $q->where(['Authors.id' => $authorId]);
            });
        }
        if ($this->request->query('entry_type')) {
            $publications->where(['Publis.entry' => $this->request->query('entry_type')]);
        }
        $publications->limit($this->request->query('limit') ?: 5);
        
        $this->set('publications', $publications);
        $this->set('_serialize', ['publications']);
    }
}